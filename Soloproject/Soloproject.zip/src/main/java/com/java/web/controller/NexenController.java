package com.java.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NexenController {

	@RequestMapping("/Nexen")
	public String nexen(){
		return "Nexen";
	}
	
	
}
